<?php
//conectamos con el servidor
$conectar=@mysql_connect('localhost','root','');
//verificar la conexion
if(!$conectar)
{
	echo "no se conecto";

}
else
{
	$base=mysql_select_db('parqueadero');
	if(!$base){

		echo "No se encontro la base de datos";
	}
}

//recuperar las variables del formulario
/*$Nombre=$_POST['nombre'];
$Apellido=$_POST['apellido'];
$genero=$_POST['boton1'];
$ciudad=$_POST['ciudad'];
$fechanac=$_POST['fechac'];
$Direccion=$_POST['direccion'];
$COrreo=$_POST['correo'];
$Telefono=$_POST['telefono'];
$Estado=$_POST['estado'];
$sede=$_POST['sede'];
$ficha=$_POST['fc'];
$vehiculo=$_POST['vehiculo'];
//hacemos la sentencia de sql
//$sql="INSERT INTO Usuario VALUES('$Nombre','$Apellido','$genero','$fechanac','$ciudad','$Direccion','$COrreo','$Telefono','$Estado','$sede','$ficha','$vehiculo')";
//ejecutar sentencia de sql*/

$Cargo=$_POST['Cargo'];
$Vehiculo=$_POST['tipo'];
$color=$_POST['Color'];
$Placa=$_POST['Placa'];
$serial=$_POST['serial'];
$modelo=$_POST['Modelo'];
$sql="INSERT INTO Vehiculo VALUES('$Cargo','$Vehiculo','$color','$Placa','$serial
','$modelo')";
$ejecutar=mysql_query($sql);

//verificamos la ejecucion
if(!$ejecutar)
{
	echo "Error";
}
else
{
	echo"<!DOCTYPE html>
<html lang=en>
<head>
	<meta charset=UTF-8>
	<meta name=viewport content=width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0>
	<link rel=stylesheet href=css/estilos.css>
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
	<title>Formularios</title>
</head>
<body>
	<div class=contenedor-formulario>
		<div class=wrap>
				<div>
					<div class=input-group>
						Sus datos se han guardado exitosamente
					</div><br><a href='Index.html'>volver</a>";
}
?>
