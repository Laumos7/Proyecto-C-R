<?php

require 'class.phpmailer.php';
require 'class.smtp.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;

//Tell PHPMailer to use SMTP
 $mail->isSMTP();

//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 2;

$mail->Timeout=60;

//Set the hostname of the mail server
$mail->Host = 'smtp.gmail.com';

//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
$mail->Port = 587;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';

//Whether to use SMTP authentication
$mail->SMTPAuth = true;

//Username to use for SMTP authentication - use full email address for gmail
$mail->Username = "soportejm3d@gmail.com";

//Password to use for SMTP authentication
$mail->Password = "administrador5";

$name=$_POST['email'];
$nombre=$_POST['nombre'];

$Comentarios=$_POST['mensaje'];


//Set who the message is to be sent from
$mail->setFrom($name, $nombre);

//Set an alternative reply-to address
$mail->addReplyTo($name, 'Nombre');

//Set who the message is to be sent to
$mail->addAddress('soportejm3d@gmail.com');


$subject=$_POST['asunto'];
//Set the subject line
$mail->Subject = $subject;

//$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));

$mail->Body = 'Datos del usuario <br><br> Nombre:'.$nombre.'<br> Asunto:'.$subject.'<br> Correo:'.$name.'<br> Comentarios: '.$Comentarios;





$mail->IsHTML(true);

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
echo '<script>alert("Su  mensaje ha sido enviado")</script> ';
echo "<script>location.href='../../controller/index.php'</script>";
}



?>