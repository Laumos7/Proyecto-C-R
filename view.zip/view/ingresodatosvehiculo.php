<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="css/estilos.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
	<title>Formularios</title>
	<style >
	
	.select {
  border: 1px solid #ccc;
  width: 140px;
  overflow: hidden;
  background: #fff url("arrowdown.gif") no-repeat 90% center;
}
  .select select {
    padding: 5px 8px;
    width: 130%;
    border: none;
    box-shadow: none;
    background-color: black;
    background-image: none;
    appearance: none;
  }


	</style>
</head>
<body>
	<div class="contenedor-formulario">
		<div class="wrap">
			<form action="../controller/administrar_vehiculo.php" class="formulario" name="formulario_registro" method="POST">
				<div>
					<div class="input-group">
						<label class="label" for="cargo">Cargo:</label><br><br>
						<select name="cargo" class="select" required>
						<option value="selected">- selecciona -</option>
						<OPTION VALUE="Aprendiz">Aprendiz</OPTION>
						<OPTION VALUE="Instructor">Instructor</OPTION>
						<OPTION VALUE="Empleado De La Entidad">Empleado De La Entidad</OPTION>
						</SELECT>						
						
					</div>

					
						<div class="input-group radio">
						<input type="radio" name="vehiculo" id="moto" value="Moto" required>
						<label for="moto">Moto</label>
						<input type="radio" name="vehiculo" id="bicicleta" value="Bicicleta" required>
						<label for="bicicleta">Bicicleta</label>
					</div>
					
					<div class="input-group">
						<label class="label" for="fecha de nacimiento">Color del vehiculo:</label><br><br>
						<SELECT name="color"  required>
						<option value=" selected">- selecciona -</option>
						<OPTION VALUE="Negro">Negro</OPTION>
						<OPTION VALUE="Blanco">Blanco</OPTION>
						<OPTION VALUE="Azul">Azul</OPTION>
						<OPTION VALUE="Rojo">Rojo</OPTION>
						<OPTION VALUE="Amarillo">Amarillo</OPTION>
						<OPTION VALUE="Naranja">Naranja</OPTION>
						<OPTION VALUE="Plateado">Plateado</OPTION>
						<OPTION VALUE="Morado">Morado</OPTION>
						</SELECT>
						
					</div>
					
					<div class="input-group">
						<input type="text" name="placa" id="Placa" required>
						<label class="label" for="Placa">Placa o numero de rin:</label>
					</div>
					<div class="input-group">
						<input type="text" name="serie" id="serial" required>
						<label class="label" for="serial">Serial:</label>
					</div>
					<div class="input-group">
						 <input type="text" name="marca" id="Marca" required>
						<label class="label" for="telefono">Marca:</label>
					</div>

					<div class="input-group">
							<label class="label" for="telefono">Documento del propietario:</label>
						
							<br><br>
							<input type="text" id="propietario" name="propietario" value="<?php
							$result1=$_GET['nombre']; 
							require("../model/conexion.php");
							require("../model/connect_db.php");
							$sql=("SELECT * from usuario
							where nombre='$result1' ");
							$query=mysqli_query($mysqli,$sql);
							while($arreglo=mysqli_fetch_array($query)){echo $arreglo[5];};
							?>" readonly>
							
						</div>


					<div class="input-group checkbox">
						<input type="checkbox" name="terminos" id="terminos" value="true">
						<label for="terminos">Acepto los Terminos y Condiciones</label>
							<input type='hidden' name='insertar' value='insertar'>
					</div>
						

					<input type="submit" id="btn-submit" value="Enviar">
				</div>
			</form>
		</div>
	</div>

	<script src="js/formulario.js"></script>
</body>
</html>