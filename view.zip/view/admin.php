<!DOCTYPE html>
<?php
session_start();
if (@!$_SESSION['user']) {
	header("Location:admin.php");
}elseif ($_SESSION['rol']==1) {
	header("Location:admin.php");
}
    require("../model/connect_db.php");
       require("../model/conexion.php");
?>
	
		
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>JM3D</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/animate.min.css" rel="stylesheet"> 
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/lightbox.css" rel="stylesheet">
  <link href="css/main.css" rel="stylesheet">
  <link id="css-preset" href="css/presets/preset1.css" rel="stylesheet">
  <link href="css/responsive.css" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>
  <link rel="shortcut icon" href="images/favicon.ico">
  <style type="text/css">
  /* Table 3 Style */
table.table3{
    font-family:Arial;
    font-size: 12px;
    font-style: normal;
    font-weight: 100;
    text-transform: uppercase;
    letter-spacing: -1px;
    line-height: 1.7em;
    text-align:center;
    border-collapse:collapse;
    top: 100;
}
.table3 thead th{
    padding:6px 10px;
    text-transform:uppercase;
    color:#444;
    text-shadow:1px 1px 1px #fff;
    border-bottom:5px solid #444;
}
.table3 thead th:empty{
    background:transparent;
    border:none;
}
.table3 thead :nth-child(2),
.table3 tfoot :nth-child(2){
    background-color: #7FD2FF;
}
.table3 tfoot :nth-child(2){
    -moz-border-radius:0px 0px 0px 5px;
    -webkit-border-bottom-left-radius:5px;
    border-bottom-left-radius:5px;
}
.table3 thead :nth-child(2){
    -moz-border-radius:5px 0px 0px 0px;
    -webkit-border-top-left-radius:5px;
    border-top-left-radius:5px;
}
.table3 thead :nth-child(3),
.table3 tfoot :nth-child(3){
    background-color: #45A8DF;
}
.table3 thead :nth-child(4),
.table3 tfoot :nth-child(4){
    background-color: #2388BF;
}
.table3 thead :nth-child(5),
.table3 tfoot :nth-child(5){
    background-color: #096A9F;
}
.table3 thead :nth-child(5){
    -moz-border-radius:0px 5px 0px 0px;
    -webkit-border-top-right-radius:5px;
    border-top-right-radius:5px;
}
.table3 tfoot :nth-child(5){
    -moz-border-radius:0px 0px 5px 0px;
    -webkit-border-bottom-right-radius:5px;
    border-bottom-right-radius:5px;
}
.table3 tfoot td{
    font-size:12px;
    font-weight:bold;
    padding:15px 0px;
    text-shadow:1px 1px 1px #fff;
}
.table3 tbody td{
    padding:20px;
}
.table3 tbody tr:nth-child(4) td{
    font-size:12px;
    font-weight:bold;
}
.table3 tbody td:nth-child(even){
    background-color:#444;
    color:#444;
    border-bottom:1px solid #444;
    background:-webkit-gradient(
        linear,
        left bottom,
        left top,
        color-stop(0.39, rgb(189,189,189)),
        color-stop(0.7, rgb(224,224,224))
        );
    background:-moz-linear-gradient(
        center bottom,
        rgb(189,189,189) 39%,
        rgb(224,224,224) 70%
        );
    text-shadow:1px 1px 1px #fff;
}
.table3 tbody td:nth-child(odd){
    background-color:#555;
    color:#f0f0f0;
    border-bottom:1px solid #444;
    background:-webkit-gradient(
        linear,
        left bottom,
        left top,
        color-stop(0.39, rgb(85,85,85)),
        color-stop(0.7, rgb(105,105,105))
        );
    background:-moz-linear-gradient(
        center bottom,
        rgb(85,85,85) 39%,
        rgb(105,105,105) 70%
        );
    text-shadow:1px 1px 1px #000;
}
.table3 tbody td:nth-last-child(1){
    border-right:1px solid #222;
}
.table3 tbody th{
    color:#696969;
    text-align:right;
    padding:0px 10px;
    border-right:1px solid #aaa;
}
.table3 tbody span.check::before{
    content : url(../images/check2.png)
}

#customers 
     {
         font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
         border-collapse: collapse;
         width: 80%;
       }

    #customers td, #customers th 
     {
        border: 1px solid #000;
        padding: 8px;
     }

    #customers tr:nth-child(even)
     {
      background-color: #ddd;
     }

    #customers tr:hover 
     {
      background-color: #ddd;
     }

    #customers th
      {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #000;
        color: white; 
      }
</style>
</head>

<body>
 <!-- <div class="preloader"> <i class="fa fa-circle-o-notch fa-spin"></i></div>!-->

  <header id="home">
    <div id="home-slider" class="carousel slide carousel-fade" data-ride="carousel">
      <div class="carousel-inner">
        <div class="item active" style="background-image: url(images/slider/1.jpg)">
          <div class="caption">
            <h1 class="animated fadeInLeftBig">Bienvenidos a <span>Colsutec</span></h1>
            <p class="animated fadeInRightBig">Un Sistema De Registro Para Un Control Oportuno</p>
            <a data-scroll class="btn btn-start animated fadeInUpBig" href="#services">Empezar Ahora</a>
          </div>
        </div>
        <div class="item" style="background-image: url(images/slider/2.jpg)">
          <div class="caption">
            <h1 class="animated fadeInLeftBig">Registration System <span>JM3D</span></h1>
            <p class="animated fadeInRightBig">Un Sistema De Registro Para Un Control Oportuno</p>
            <a data-scroll class="btn btn-start animated fadeInUpBig" href="#services">Empezar Ahora</a>
          </div>
        </div>
        <div class="item" style="background-image: url(images/slider/3.jpg)">
          <div class="caption">
            <h1 class="animated fadeInLeftBig">Somos Una Empresa <span>Creativa</span></h1>
            <p class="animated fadeInRightBig"></p>
            <a data-scroll class="btn btn-start animated fadeInUpBig" href="#services">Empezar Ahora</a>
          </div>
        </div>
      </div>
      <a class="left-control" href="#home-slider" data-slide="prev"><i class="fa fa-angle-left"></i></a>
      <a class="right-control" href="#home-slider" data-slide="next"><i class="fa fa-angle-right"></i></a>

      <a id="tohash" href="#services"><i class="fa fa-angle-down"></i></a>

    </div><!--/#home-slider-->
    <div class="main-nav">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
             <span class="icon-bar"></span>
          </button>                    
        </div>
        <div class="collapse navbar-collapse">
          <ul class="nav navbar-nav navbar-right">  
            <li><a href="../controller/desconectar.php"> Bienvenido <?php echo $_SESSION['user'];?>  Cerrar Cesión </a></li> 
            <li class="scroll active"><a href="#home">Inicio</a></li>
            
            <li class="scroll"><a href="#services">Datos personas</a></li> 
            <li class="scroll"><a href="#team">Informacion Novedades</a></li>
            <li class="scroll"><a href="#about">Datos cuentas</a></li>                     
            <li class="scroll"><a href="#portfolio">Datos de los vehiculos</a></li>
            
               
          </ul>
        </div>
      </div>
    </div><!--/#main-nav-->
  </header><!--/#home-->



 <section id="services">  
     <br><br><br><br>
       <center>
        <font face="comic-sans" size="18"><b>Buscar Usuario </b></font>
        <br><br><br>
        <form action="#" method="POST">
          <input type="text " name="doc"> 
          <input type="submit" name="Buscar" value="buscar"> 
        </form>
        <br><br><br>
        <font face="comic-sans" size="18"><b>Información Usuario Consultado </b></font>

<?php echo "<Font color=black>";
//Ejemplo con variable definida

if(isset($_POST["Buscar"]))
  {
       $doc=$_POST['doc'];
   
       $sql=("SELECT id as id,nombre as Nombre,apellido as Apellido,genero,tipodedocumento.Descripcion,documento,edad,ciudad.descripcion,direccion,correo,telefono,sede,estado from usuario,tipodedocumento,ciudad where(usuario.idTipoDoc=tipodedocumento.codigo) 
        and (usuario.idciudad=ciudad.idCiudad) and documento=$doc ");
        $query=mysqli_query($mysqli,$sql);

          echo " <table  border='2'; id='customers'>";
          echo "<tr class='warning'>";
          echo "<tH>Id</tH>";
          echo "<td>Nombre</td>";
          echo "<td>Apellido</td>";
          echo "<td>Genero</td>";
          echo "<td>Tipo de documento</td>";
          echo "<td>Documento</td>";        
          echo "<td>Fecha de Nacimiento</td>";
          echo "<td>Ciudad</td>";
          echo "<td>Direccion</td>";
          echo "<td>Correo</td>";
          echo "<td>Telefono</td>";
          echo "<td>Sede</td>";
          echo "<td>Estado</td>";
          echo "<td>Actualizar</td>";           
          echo "</tr>";      
      ?>
        
      <?php 
         while($arreglo=mysqli_fetch_array($query)){
            echo "<tr class='success'>";
              echo "<td>$arreglo[0]</td>";
              echo "<td>$arreglo[1]</td>";
              echo "<td>$arreglo[2]</td>";
              echo "<td>$arreglo[3]</td>";
              echo "<td>$arreglo[4]</td>";
              echo "<td>$arreglo[5]</td>";
              echo "<td>$arreglo[6]</td>";
              echo "<td>$arreglo[7]</td>";
              echo "<td>$arreglo[8]</td>";
              echo "<td>$arreglo[9]</td>";
              echo "<td>$arreglo[10]</td>";
              echo "<td>$arreglo[11]</td>";  
              echo "<td>$arreglo[12]</td>";     
              echo "  <td><a href=actualizaradminusuario.php?id=$arreglo[0]&accion=a>Actualizar</a> </td>";
            
          echo "</tr>";
        }
       echo "</table>";
      }
     
     echo "<br><br><br><br>";

      echo "<font face=comic-sans size=18><b>Información Usuarios </b></font>";
      extract($_GET);
      $sql=("SELECT id as id,nombre as Nombre,apellido as Apellido,genero,tipodedocumento.Descripcion,documento,edad,ciudad.descripcion,direccion,correo,telefono,sede,estado from usuario,tipodedocumento,ciudad where(usuario.idTipoDoc=tipodedocumento.codigo) 
        and (usuario.idciudad=ciudad.idCiudad) "); 

      $query=mysqli_query($mysqli,$sql);

        echo " <table border='0'; class='table3';>";
        echo "<tr class='warning'>";
        echo "<td>Id</td>";
        echo "<td>Nombre</td>";
        echo "<td>Apellido</td>";
        echo "<td>Genero</td>";
        echo "<td>Tipo de documento</td>";
        echo "<td>Documento</td>";
        echo "<td>Fecha de Nacimiento</td>";
        echo "<td>Ciudad</td>";
        echo "<td>Direccion</td>";
        echo "<td>Correo</td>";
        echo "<td>Telefono</td>";
        echo "<td>Sede</td>";
        echo "<td>Estado</td>";
        echo "<td>Actualizar</td>";             
        echo "</tr>";

          
      ?>
        
      <?php 
         while($arreglo=mysqli_fetch_array($query)){
            echo "<tr class='success'>";
              echo "<td>$arreglo[0]</td>";
              echo "<td>$arreglo[1]</td>";
              echo "<td>$arreglo[2]</td>";
              echo "<td>$arreglo[3]</td>";
              echo "<td>$arreglo[4]</td>";
              echo "<td>$arreglo[5]</td>";
              echo "<td>$arreglo[6]</td>";
              echo "<td>$arreglo[7]</td>";
              echo "<td>$arreglo[8]</td>";
              echo "<td>$arreglo[9]</td>";
              echo "<td>$arreglo[10]</td>";
              echo "<td>$arreglo[11]</td>";  
              echo "<td>$arreglo[12]</td>";     
              echo "   <td><a href=actualizaradminusuario.php?id=$arreglo[0]&accion=a>Actualizar</a> </td>";
            
            
          echo "</tr>";
        }
         echo "<tr><td colspan=15><a href=creaPDF1.php><input type=button  value=Imprimir></a></td></tr></table>";
?>
<br><br><br><br>
</table>
</section>

  <section id="team">  
<br><br><br><br>
<center>
 <font face="comic-sans" size="18"><b>Información Novedades
<?php echo "<Font color=black>";

  extract($_GET);



            $sql=("SELECT idnovedad as id,tipodedocumento.Descripcion,documento,novedad,fecha
from novedad,tipodedocumento where (novedad.TipoDoc=tipodedocumento.codigo) ");
       
  
//la variable  $mysqli viene de connect_db que lo traigo con el require("connect_db.php");
        $query=mysqli_query($mysqli,$sql);

        echo " <br><br><br><br><br><br> <table border='0'; class='table3';>";
          echo "<tr class='warning'>";
            echo "<td>Id</td>";
            echo "<td>Tipo Documento</td>";
            echo "<td>Documento</td>";
               echo "<td>Novedad</td>";
            echo "<td>Fecha</td>";

         
         
                     
          echo "</tr>";
          
      ?>
        
      <?php 
         while($arreglo=mysqli_fetch_array($query)){
            echo "<tr class='success'>";
              echo "<td>$arreglo[0]</td>";
              echo "<td>$arreglo[1]</td>";
              echo "<td>$arreglo[2]</td>";
              echo "<td>$arreglo[3]</td>";    
              echo "<td>$arreglo[4]</td>";    

              

 
            
          echo "</tr>";
        }
           echo "<tr><td colspan=5><a href=creaPDF3.php><input type=button  value=Imprimir></a></td></tr></table>";
?>
<br><br><br><br>
</table></section>

 <section id="about"> 
  <center>
 <font face="comic-sans" size="18"><b>Información Cuentas
 
  <?php

        require("../model/connect_db.php");
        $sql=(" SELECT * FROM  login ");
  
//la variable  $mysqli viene de connect_db que lo traigo con el require("connect_db.php");
        $query=mysqli_query($mysqli,$sql);

        echo " <br><br><br><br><br><br> <table border='0'; class='table3';>";
          echo "<tr class='warning'>";
            echo "<td>Id</td>";
            echo "<td>Usaurio</td>";
            echo "<td>Password</td>";
            echo "<td>Correo</td>";
           
            echo "<td>Editar</td>";
            echo "<td>Borrar</td>";
          echo "</tr>";

          
      ?>
        
      <?php 
         while($arreglo=mysqli_fetch_array($query)){
            echo "<tr class='success'>";
              echo "<td>$arreglo[0]</td>";
              echo "<td>$arreglo[1]</td>";
              echo "<td>$arreglo[2]</td>";
              echo "<td>$arreglo[3]</td>";
          
              echo "<td><a href='actualizarad.php?id=$arreglo[0]'>Actualizar</a></td>";
            echo "<td><a href='admin.php?id=$arreglo[0]&idborrar=2'>Eliminar</a></td>";
            

            
          echo "</tr>";
        }
        
       echo "<tr><td colspan=15><a href=creaPDF4.php><input type=button  value=Imprimir></a></td></tr></table>";

          extract($_GET);
          if(@$idborrar==2){
    
            $sqlborrar="DELETE FROM login WHERE id=$id";
            $resborrar=mysqli_query($mysqli,$sqlborrar);
            echo '<script>alert("REGISTRO ELIMINADO")</script> ';
            //header('Location: proyectos.php');
            echo "<script>location.href='admin.php'</script>";
          }

      ?>
      </section>
       <section id="portfolio">
      <center><br><br>
    
            <font face="comic-sans" size="18"><b>Información Vehiculos
    <br><br>
     
<?php echo "<Font color=black>";

  extract($_GET);

   $sql=("SELECT id,cargo,vehiculo,color,placa,serie,marca,propietario from vehiculo ");
       
  
//la variable  $mysqli viene de connect_db que lo traigo con el require("connect_db.php");
        $query=mysqli_query($mysqli,$sql);

        echo " <br><br><br><br><br><br> <table border='0'; class='table3';>";
          echo "<tr class='warning'>";
            echo "<td>Id</td>";
            echo "<td>Cargo</td>";
            echo "<td>Vehiculo</td>";
               echo "<td>Color</td>";
            echo "<td>PLaca</td>";
            echo "<td>Serial</td>";
            echo "<td>Modelo</td>";
            echo "<td>Propietario</td>";
            echo "<td>Actualizar</td>";
            echo "<td>Eliminar</td>";
         
                     
          echo "</tr>";
          
      ?>
        
      <?php 
         while($arreglo=mysqli_fetch_array($query)){
            echo "<tr class='success'>";
              echo "<td>$arreglo[0]</td>";
              echo "<td>$arreglo[1]</td>";
              echo "<td>$arreglo[2]</td>";
              echo "<td>$arreglo[3]</td>";    
              echo "<td>$arreglo[4]</td>";    
              echo "<td>$arreglo[5]</td>";
              echo "<td>$arreglo[6]</td>";    
              echo "<td>$arreglo[7]</td>"; 
              echo "   <td><a href=actualizarav.php?id=$arreglo[0]&accion=a>Actualizar</a> </td>";
              echo " <td><a href=administrar_vehiculo1.php?id=$arreglo[0]&accion=e>Eliminar</a>   </td>";
          

 
            
          echo "</tr>";
        }
         echo "<tr><td colspan=15><a href=creaPDF2.php><input type=button  value=Imprimir></a></td></tr></table>";
?>
          

    
      
<br><br><br><br>
    
    </div>
  </section><!--/#services-->    
    <div class="span8">
    </div>
        </div>
      </div>
    </div>  
    </div>  
    <br/>

    <!--EMPIEZA DESLIZABLE-->
    
     <!--TERMINA DESLIZABLE-->

    </div>
  <script type="text/javascript" src="js/jquery.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
  <script type="text/javascript" src="js/jquery.inview.min.js"></script>
  <script type="text/javascript" src="js/wow.min.js"></script>
  <script type="text/javascript" src="js/mousescroll.js"></script>
  <script type="text/javascript" src="js/smoothscroll.js"></script>
  <script type="text/javascript" src="js/jquery.countTo.js"></script>
  <script type="text/javascript" src="js/lightbox.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>

</body>
</html>