
<?php
// incluye la clase Db
require_once('../model/conexion.php');
 
	class CrudUsuario{
		// constructor de la clase
		public function __construct(){}
 
		// método para insertar, recibe como parámetro un objeto de tipo libro
		public function insertar($usuario){
			$db=Db::conectar();
			$insert=$db->prepare('INSERT INTO usuario values(NULL,:nombre,:apellido,:genero,:idTipoDoc,:documento,:edad,:idciudad,:direccion,:correo,:telefono,:sede,DEFAULT)');
			$insert->bindValue('nombre',$usuario->getNombre());
			$insert->bindValue('apellido',$usuario->getApellido());
			$insert->bindValue('genero',$usuario->getGenero());
			$insert->bindValue('idTipoDoc',$usuario->getTipoDoc());
			$insert->bindValue('documento',$usuario->getdocumento());
			$insert->bindValue('edad',$usuario->getedad());
			$insert->bindValue('idciudad',$usuario->getciudad());
			$insert->bindValue('direccion',$usuario->getdireccion());
			$insert->bindValue('correo',$usuario->getcorreo());
			$insert->bindValue('telefono',$usuario->gettelefono());
			$insert->bindValue('sede',$usuario->getsede());
			$insert->execute();
 
		}
 
		// método para mostrar todos los libros
		public function mostrar(){
			$db=Db::conectar();
			$listausuarios=[];
			$select=$db->query('SELECT * FROM usuario');
 
			foreach($select->fetchAll() as $usuario){
				$myusuario= new Usuario();
				$myusuario->setId($usuario['id']);
				$myusuario->setNombre($usuario['nombre']);
				$myusuario->setApellido($usuario['apellido']);
				$myusuario->setGenero($usuario['genero']);
				$myusuario->setTipoDoc($usuario['idTipoDoc']);
				$myusuario->setdocumento($usuario['documento']);
				$myusuario->setedad($usuario['edad']);
				$myusuario->setciudad($usuario['idciudad']);
				$myusuario->setdireccion($usuario['direccion']);
				$myusuario->setcorreo($usuario['correo']);
				$myusuario->settelefono($libro['telefono']);
				$myusuario->setsede($usuario['sede']);
				$myusuario->setestado($usuario['estado']);
				$listausuarios[]=$myusuario;
			}
			return $listausuarios;
		}

		public function mostrar1($documento){
			$db=Db::conectar();
			$listausuarios=[];
			$select=$db->query('SELECT * FROM usuario WHERE documento=:documento');
 
			foreach($select->fetchAll() as $usuario){
				$myusuario= new Usuario();
				$myusuario->setId($usuario['id']);
				$myusuario->setNombre($usuario['nombre']);
				$myusuario->setApellido($usuario['apellido']);
				$myusuario->setGenero($usuario['genero']);
				$myusuario->setTipoDoc($usuario['idTipoDoc']);
				$myusuario->setdocumento($usuario['documento']);
				$myusuario->setedad($usuario['edad']);
				$myusuario->setciudad($usuario['idciudad']);
				$myusuario->setdireccion($usuario['direccion']);
				$myusuario->setcorreo($usuario['correo']);
				$myusuario->settelefono($libro['telefono']);
				$myusuario->setsede($usuario['sede']);
				$myusuario->setestado($usuario['estado']);
				$listausuarios[]=$myusuario;
			
			}
			return $listausuarios;
		}





 
		// método para eliminar un libro, recibe como parámetro el id del libro
		public function eliminar($id){
			$db=Db::conectar();
			$eliminar=$db->prepare('DELETE FROM usuario WHERE ID=:id');
			$eliminar->bindValue('id',$id);
			$eliminar->execute();
		}
 
		// método para buscar un libro, recibe como parámetro el id del libro
		public function obtenerLibro($id){
			$db=Db::conectar();
			$select=$db->prepare('SELECT * FROM usuario WHERE documento=:id');
			$select->bindValue('id',$id);
			$select->execute();
			$usuario=$select->fetch();
			$myusuario= new Usuario();
			$myusuario->setId($usuario['id']);
				$myusuario->setNombre($usuario['nombre']);
				$myusuario->setApellido($usuario['apellido']);
				$myusuario->setGenero($usuario['genero']);
				$myusuario->setTipoDoc($usuario['idTipoDoc']);
				$myusuario->setdocumento($usuario['documento']);
				$myusuario->setedad($usuario['edad']);
				$myusuario->setciudad($usuario['idciudad']);
				$myusuario->setdireccion($usuario['direccion']);
				$myusuario->setcorreo($usuario['correo']);
				$myusuario->settelefono($usuario['telefono']);
				$myusuario->setsede($usuario['sede']);
				$myusuario->setestado($usuario['estado']);
			return $myusuario;
		}
 
		// método para actualizar un libro, recibe como parámetro el libro
		public function actualizar($usuario){
			$db=Db::conectar();
			$actualizar=$db->prepare('UPDATE usuario SET nombre=:nombre, apellido=:apellido, genero=:genero, idTipoDoc=:TipoDoc, documento=:documento, edad=:edad, idciudad=:ciudad, direccion=:direccion,correo=:correo,telefono=:telefono,sede=:sede,estado=:estado WHERE ID=:id');
			$actualizar->bindValue('id',$usuario->getId());
			$actualizar->bindValue('nombre',$usuario->getNombre());
			$actualizar->bindValue('apellido',$usuario->getApellido());
			$actualizar->bindValue('genero',$usuario->getGenero());
			$actualizar->bindValue('TipoDoc',$usuario->getTipoDoc());
			$actualizar->bindValue('documento',$usuario->getdocumento());
			$actualizar->bindValue('edad',$usuario->getedad());
			$actualizar->bindValue('ciudad',$usuario->getciudad());
			$actualizar->bindValue('direccion',$usuario->getdireccion());
			$actualizar->bindValue('correo',$usuario->getcorreo());
			$actualizar->bindValue('telefono',$usuario->gettelefono());
			$actualizar->bindValue('sede',$usuario->getsede());
			$actualizar->bindValue('estado',$usuario->getestado());
			$actualizar->execute();
		}
	}
?>